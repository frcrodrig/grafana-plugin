# Ushop Cross Time Graph Panel Plugin for Advantech

## 1.0.0

### New Feature
- legend图例组件显示/隐藏，类型，定位,朝向,标记类型
- grid直角坐标系内绘图网格定位，间距
- xAxis底部x轴类目数据，留白，分割线
- yAxis左侧y轴分割线
- color颜色列表，根据series数量变化
- tooltip提示框组件显示/隐藏，触发类型，指示器类型
- toolbox工具栏显示/隐藏，朝向，工具配置，定位
- animation动画
- series系列列表,类型，堆叠，平滑曲线,阶梯线图,
  - line线宽，填充透明度


## 1.0.1

### New Feature 
- 客制化year：Custom-Year


## 1.0.2

### New Feature
- 客制化year:Custom-Month


## 1.0.3

### New Feature
- 客制化year:Custom-FullMonth

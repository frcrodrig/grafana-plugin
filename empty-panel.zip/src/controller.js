import { MetricsPanelCtrl } from 'app/plugins/sdk';
import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import $ from 'jquery';
import echarts from './libs/echarts.min';
import './libs/dark';
import './style.css!';
// import './libs/china.js';
import './libs/bmap.js';
import './libs/getBmap.js';

import { DataProcessor } from './data_processor';
import DataFormatter from './data_formatter';

export class Controller extends MetricsPanelCtrl {

  constructor($scope, $injector) {
    // console.log('constructor');
    super($scope, $injector);

    var panelDefaults = {
      IS_UCD: false,
      url: '',
      method: 'POST',
      upInterval: 60000,
      format: 'Year'
    };


    panelDefaults.setOption={
      legend: {
        left:'auto',
        top:'bottom',
        align:'auto'
      },
      grid: {
        left: '10%',
        top:'60',
        right: '10%',
        bottom: '60',
        containLabel:true
      },
      xAxis: [{
        type: 'category',
        data: [],
        boundaryGap: false,
        splitLine : {
          show : true,
          lineStyle:{
            type:'solid',
            opacity:'0.3'
          }
        }
      }],
      yAxis: [{
        type: 'value', 
        splitLine : {
          show : true,
          lineStyle:{
            type:'solid',
            opacity:'0.3'
          }
        }
      }],
      color: [],
      tooltip: {
        trigger: 'axis'
      },
      series: []
    };

        // console.log(this.panel);
        _.defaults(this.panel, panelDefaults);
        console.log(this);
        console.log(this.panel);
        console.log(this.setOption);


        this.dataFormatter = new DataFormatter(this, kbn);
        this.processor = new DataProcessor(this.panel);
        
        // console.log(this);


        this.events.on('data-received', this.onDataReceived.bind(this));
        this.events.on('data-error', this.onDataError.bind(this));
        this.events.on('data-snapshot-load', this.onDataReceived.bind(this));
        this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
        this.events.on('panel-initialized', this.render.bind(this));

        this.refreshData();
      }


      onDataReceived(dataList) {
        // console.log('onDataReceived');

          // console.log('onDataReceived--time-Over');
          // console.log(this);
          // console.log(dataList);
          // console.log(dataList.length);
          this.seriesList={dataList:dataList,xAxisOp:[],seriesOp:[]};
          
          if(this.panel.format==='Year'){
            this.seriesList.xAxisOp=['1/1','2/1','3/1','4/1','5/1','6/1','7/1','8/1','9/1','10/1','11/1','12/1'];
          }else if(this.panel.format==='Month'){
            this.seriesList.xAxisOp=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'];
          }else if(this.panel.format==='Week'){
            this.seriesList.xAxisOp=['Mon','Tue','Wed','Thur','Fri','Sat','Sun'];
          }else if(this.panel.format==='Day'){
            this.seriesList.xAxisOp=['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
          }else{

          }
          for(var i in dataList){
           this.seriesList.seriesOp.push({name:dataList[i].target,type:'line',stark:'比较',data:[]});
           // console.log(this.seriesList.seriesOp);
           for(var j in dataList[i].datapoints){
            // console.log('dataList[i].datapoints');
            // console.log(dataList[i].datapoints);
            this.seriesList.seriesOp[i].data.push(dataList[i].datapoints[j][0]);
          }
          // console.log(this.seriesList.seriesOp);
        }
        // console.log(this.seriesList);


        this.refreshed = true;
        this.render();
        this.refreshed = false;
      }

      onDataError(err) {
      // console.log('onDataError');
      this.series = [];
      this.render();
    }

    onInitEditMode() {
      this.addEditorTab('Option', 'public/plugins/empty-panel/partials/options.html', 2);
    }


    refreshData() {
      // console.log("refreshData");
      let _this = this, xmlhttp;

      if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
      } else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
      }

      let data = [];
      xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
          _this.customizeData = JSON.parse(xmlhttp.responseText);
          _this.onDataReceived();
        }
      };

      if (this.panel.IS_UCD) {
        xmlhttp.open(_this.panel.method, _this.panel.url, true);
        xmlhttp.send();
      } else {
        xmlhttp = null;
      }

      this.$timeout(() => { this.refreshData(); }, _this.panel.upInterval);
    }

    link(scope, elem, attrs, ctrl) {
      const $panelContainer = elem.find('.echarts_container')[0];


      ctrl.refreshed = true;

      function setHeight() {
        let height = ctrl.height || panel.height || ctrl.row.height;
        if (_.isString(height)) {
          height = parseInt(height.replace('px', ''), 10);
        }

        height += 0;

        $panelContainer.style.height = height + 'px';
      }

      setHeight();

      let myChart = echarts.init($panelContainer, 'dark');

      setTimeout(function () {
        myChart.resize();
      }, 1000);






      function render() {
        // console.log("render()");

        if (!myChart) {
          return;
        }

        setHeight();
        myChart.resize();
        // console.log(ctrl.refreshed);

        if (ctrl.refreshed) {
          // console.log("if--ctrl.refreshed");
          myChart.clear();

          let option = ctrl.panel.setOption;

          if(ctrl.seriesList!==undefined){
           option.xAxis[0].data=ctrl.seriesList.xAxisOp;
           option.series=ctrl.seriesList.seriesOp;
         }else{
           option.xAxis[0].data = [];
           option.series = [];
         }
         // option.color=['#c23531','#2f4554', '#61a0a8', '#d48265', '#91c7ae','#749f83',  '#ca8622', '#bda29a','#6e7074', '#546570', '#c4ccd3'];

         option.legend.data=[];
          // console.log(seriesOp);
          for(var i in option.series){
            option.legend.data.push(option.series[i].name);
          }


          // console.log(option);
          myChart.setOption(option);
        }
      }

      this.events.on('render', function () {
        render();
        ctrl.renderingCompleted();
      });
    }
  }

  Controller.templateUrl = 'partials/module.html';
